Return <- LOWER("SPARTAAA!")


expect_equal(Return,"spartaaa!")
