Return1 <- ISODD(1)
Return2 <- ISODD(2)


expect_equal(Return1,T)
expect_equal(Return2,F)
