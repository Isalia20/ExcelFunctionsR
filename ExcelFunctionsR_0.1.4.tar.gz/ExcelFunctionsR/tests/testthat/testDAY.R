Return <- DAY(DATE(2020,2,20))


expect_equal(Return,20)
