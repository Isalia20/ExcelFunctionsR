Return <- DATE(2020,1,1)


expect_equal(Return,as.Date("2020-1-1"))

