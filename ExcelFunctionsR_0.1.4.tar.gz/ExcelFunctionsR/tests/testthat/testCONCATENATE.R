Return <- CONCATENATE("I love"," writing tests")


expect_equal(Return,"I love writing tests")



