Return <- YEAR(DATE(2020,1,1))


expect_equal(Return,2020)
