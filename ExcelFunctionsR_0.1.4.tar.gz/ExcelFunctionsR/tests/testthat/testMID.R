Return <- MID("This is a string!",6,2)


expect_equal(Return,"is")
