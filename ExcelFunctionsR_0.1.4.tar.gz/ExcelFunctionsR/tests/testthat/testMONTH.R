Return <- MONTH(DATE(2020,12,1))


expect_equal(Return,12)
