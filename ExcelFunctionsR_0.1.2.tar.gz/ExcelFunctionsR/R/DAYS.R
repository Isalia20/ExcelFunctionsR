# DAYS Function from Excel
#' Basic DAYS function from excel
#'
#' It acts similiarly to Excel's DAYS function.
#'
#' @param start_date Give the start_date argument so it can calculate days.
#' @param end_date Give the end_date argument so it can calculate days.
#' @import base
#' @import lubridate
#' @export
#' @examples
#' DAYS(DATE(2020,2,1),DATE(2020,2,15))

DAYS <-
function(start_date,end_date){

  extract_numeric(end_date - start_date)

}

