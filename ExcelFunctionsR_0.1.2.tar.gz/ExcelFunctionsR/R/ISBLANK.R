# ISBLANK Function from Excel
#' Basic ISBLANK function from excel
#'
#' It acts similiarly to Excel's ISBLANK function.
#'
#' @param value Give the function the value for it to evaluate if it is blank?In R words if it is NA. NA is blank in R.
#' @import base
#' @export
#' @examples
#' ISBLANK(NA)
#' ISBLANK(212)
#' ISBLANK("asdasd")
#' ISBLANK(iris$Species)

ISBLANK <-
function(value){

  is.na(value)

}
