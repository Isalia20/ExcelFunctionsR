# ISLOGICAL Function from Excel
#' Basic ISLOGICAL function from excel
#'
#' It acts similiarly to Excel's ISLOGICAL function.
#'
#' @param value Input the number for it to evaluate if it is logical? Works on vectors/arrays as well.
#' @import base
#' @export
#' @examples
#' ISLOGICAL(TRUE)
#' ISLOGICAL(FALSE)
#' ISLOGICAL("Is this a logical?")

ISLOGICAL <-
function(value){

      is.logical(value)
}
