# MAXIF Function from Excel
#' Basic MAXIF function from excel
#'
#' It acts similiarly to Excel's MAXIF function.
#'
#' @param range Range where it should check the criteria
#' @param criteria Where should it lookup the value
#' @param max_range Which array should it return the max from.
#' @import base
#' @import stringr
#' @export
#' @examples
#' MAXIF(iris$Species,"virginica",iris$Sepal.Length)

MAXIF <-
function(range,criteria, max_range) {

  options(warn=-1)

  if(is.na(as.numeric(criteria)) == F){
    c1 <- "=="
  } else if (str_detect(criteria,"^>") == T){
    c1 <- ">"
    criteria <- extract_numeric(criteria)
  }  else if (str_detect(criteria,"^<") == T){
    c1 <- "<"
    criteria <- extract_numeric(criteria)
  } else if (str_detect(criteria,"^>=")){
    c1 <- ">="
    criteria <- extract_numeric(criteria)
  } else if (str_detect(criteria,"^<=")){
    c1 <- "<="
    criteria <- extract_numeric(criteria)
  } else if (is.character(criteria) == T){
    c1 <- "=="
  }

  ret <- max(max_range[get(c1)(range,criteria)] )
  options(warn=0)
  ret
}
