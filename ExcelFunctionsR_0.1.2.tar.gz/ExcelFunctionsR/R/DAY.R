# DAY Function from Excel
#' Basic DAY function from excel
#'
#' It acts similiarly to Excel's DAY function.
#'
#' @param date Give the date argument so it can extract day from the date.
#' @import base
#' @import lubridate
#' @export
#' @examples
#' DAY(DATE(2020,1,13))

DAY <-
function(date){

  as.numeric(format(date, '%d'))

}




