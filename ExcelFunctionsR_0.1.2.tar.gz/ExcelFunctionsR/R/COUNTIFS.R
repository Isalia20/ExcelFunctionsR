# COUNTIFS Function from Excel
#' Basic COUNTIFS function from excel
#'
#' It acts similiarly to Excel's COUNTIFS function.
#'
#' @param criteria_range1,criteria_range2,criteria_range3,criteria_range4,criteria_range5,criteria_range6,criteria_range7,criteria_range8,criteria_range9,criteria_range10 Specify range for Countifs, only criteria_range1 is mandatory.
#' @param criteria1,criteria2,criteria3,criteria4,criteria5,criteria6,criteria7,criteria8,criteria9,criteria10 Give the criteria to check the range for.Only criteria1 is necessary, others are optional.
#' @import base
#' @import stringr
#' @export
#' @examples
#' COUNTIFS(iris$Species,"setosa",iris$Petal.Width,0.2)


COUNTIFS <-
  function(criteria_range1 , criteria1, criteria_range2 = T ,criteria2 = T,
           criteria_range3 = T ,criteria3 = T ,criteria_range4 = T ,criteria4 = T,criteria_range5 = T ,criteria5 = T ,criteria_range6 = T ,criteria6 = T ,criteria_range7 = T ,
           criteria7 = T ,criteria_range8 = T ,criteria8 = T ,criteria_range9 = T ,criteria9 = T ,criteria_range10 = T ,criteria10 = T ){

    options(warn=-1)

    if(is.na(as.numeric(criteria1)) == F){
      c1 <- "=="
    } else if (str_detect(criteria1,"^>") == T){
      c1 <- ">"
      criteria1 <- extract_numeric(criteria1)
    }  else if (str_detect(criteria1,"^<") == T){
      c1 <- "<"
      criteria1 <- extract_numeric(criteria1)
    } else if (str_detect(criteria1,"^>=")){
      c1 <- ">="
      criteria1 <- extract_numeric(criteria1)
    } else if (str_detect(criteria1,"^<=")){
      c1 <- "<="
      criteria1 <- extract_numeric(criteria1)
    } else if (is.character(criteria1) == T){
      c1 <- "=="
    }


    if(is.na(as.numeric(criteria2)) == F){
      c2 <- "=="
    } else if (str_detect(criteria2,"^>") == T){
      c2 <- ">"
      criteria2 <- extract_numeric(criteria2)
    }  else if (str_detect(criteria2,"^<") == T){
      c2 <- "<"
      criteria2 <- extract_numeric(criteria2)
    } else if (str_detect(criteria2,"^>=")){
      c2 <- ">="
      criteria2 <- gsub(pattern = ">=", replacement = "",criteria2)
      criteria2 <- as.numeric(criteria2)
    } else if (str_detect(criteria2,"^<=")){
      c2 <- "<="
      criteria2 <- extract_numeric(criteria2)
    } else if (is.character(criteria2) == T){
      c2 <- "=="
    }


    if(is.na(as.numeric(criteria3)) == F){
      c3 <- "=="
    } else if (str_detect(criteria3,"^>") == T){
      c3 <- ">"
      criteria3 <- extract_numeric(criteria3)
    }  else if (str_detect(criteria3,"^<") == T){
      c3 <- "<"
      criteria3 <- extract_numeric(criteria3)
    } else if (str_detect(criteria3,"^>=")){
      c3 <- ">="
      criteria3 <- extract_numeric(criteria3)
    } else if (str_detect(criteria3,"^<=")){
      c3 <- "<="
      criteria3 <- extract_numeric(criteria3)
    } else if (is.character(criteria3) == T){
      c3 <- "=="
    }



    if(is.na(as.numeric(criteria4)) == F){
      c4 <- "=="
    } else if (str_detect(criteria4,"^>") == T){
      c4 <- ">"
      criteria4 <- extract_numeric(criteria4)
    }  else if (str_detect(criteria4,"^<") == T){
      c4 <- "<"
      criteria4 <- extract_numeric(criteria4)
    } else if (str_detect(criteria4,"^>=")){
      c4 <- ">="
      criteria4 <- extract_numeric(criteria4)
    } else if (str_detect(criteria4,"^<=")){
      c4 <- "<="
      criteria4 <- extract_numeric(criteria4)
    } else if (is.character(criteria4) == T){
      c4 <- "=="
    }

    if(is.na(as.numeric(criteria5)) == F){
      c5 <- "=="
    } else if (str_detect(criteria5,"^>") == T){
      c5 <- ">"
      criteria5 <- extract_numeric(criteria5)
    }  else if (str_detect(criteria5,"^<") == T){
      c5 <- "<"
      criteria5 <- extract_numeric(criteria5)
    } else if (str_detect(criteria5,"^>=")){
      c5 <- ">="
      criteria5 <- extract_numeric(criteria5)
    } else if (str_detect(criteria5,"^<=")){
      c5 <- "<="
      criteria5 <- extract_numeric(criteria5)
    } else if (is.character(criteria5) == T){
      c5 <- "=="
    }



    if(is.na(as.numeric(criteria6)) == F){
      c6 <- "=="
    } else if (str_detect(criteria6,"^>") == T){
      c6 <- ">"
      criteria6 <- extract_numeric(criteria6)
    }  else if (str_detect(criteria6,"^<") == T){
      c6 <- "<"
      criteria6 <- extract_numeric(criteria6)
    } else if (str_detect(criteria6,"^>=")){
      c6 <- ">="
      criteria6 <- extract_numeric(criteria6)
    } else if (str_detect(criteria6,"^<=")){
      c6 <- "<="
      criteria6 <- extract_numeric(criteria6)
    } else if (is.character(criteria6) == T){
      c6 <- "=="
    }


    if(is.na(as.numeric(criteria7)) == F){
      c7 <- "=="
    } else if (str_detect(criteria7,"^>") == T){
      c7 <- ">"
      criteria7 <- extract_numeric(criteria7)
    }  else if (str_detect(criteria7,"^<") == T){
      c7 <- "<"
      criteria7 <- extract_numeric(criteria7)
    } else if (str_detect(criteria7,"^>=")){
      c7 <- ">="
      criteria7 <- extract_numeric(criteria7)
    } else if (str_detect(criteria7,"^<=")){
      c7 <- "<="
      criteria7 <- extract_numeric(criteria7)
    } else if (is.character(criteria7) == T){
      c7 <- "=="
    }

    if(is.na(as.numeric(criteria8)) == F){
      c8 <- "=="
    } else if (str_detect(criteria8,"^>") == T){
      c8 <- ">"
      criteria8 <- extract_numeric(criteria8)
    }  else if (str_detect(criteria8,"^<") == T){
      c8 <- "<"
      criteria8 <- extract_numeric(criteria8)
    } else if (str_detect(criteria8,"^>=")){
      c8 <- ">="
      criteria8 <- extract_numeric(criteria8)
    } else if (str_detect(criteria8,"^<=")){
      c8 <- "<="
      criteria8 <- extract_numeric(criteria8)
    } else if (is.character(criteria8) == T){
      c8 <- "=="
    }

    if(is.na(as.numeric(criteria9)) == F){
      c9 <- "=="
    } else if (str_detect(criteria9,"^>") == T){
      c9 <- ">"
      criteria9 <- extract_numeric(criteria9)
    }  else if (str_detect(criteria9,"^<") == T){
      c9 <- "<"
      criteria9 <- extract_numeric(criteria9)
    } else if (str_detect(criteria9,"^>=")){
      c9 <- ">="
      criteria9 <- extract_numeric(criteria9)
    } else if (str_detect(criteria9,"^<=")){
      c9 <- "<="
      criteria9 <- extract_numeric(criteria9)
    } else if (is.character(criteria9) == T){
      c9 <- "=="
    }

    if(is.na(as.numeric(criteria10)) == F){
      c10 <- "=="
    } else if (str_detect(criteria10,"^>") == T){
      c10 <- ">"
      criteria10 <- extract_numeric(criteria10)
    }  else if (str_detect(criteria10,"^<") == T){
      c10 <- "<"
      criteria10 <- extract_numeric(criteria10)
    } else if (str_detect(criteria10,"^>=")){
      c10 <- ">="
      criteria10 <- extract_numeric(criteria10)
    } else if (str_detect(criteria10,"^<=")){
      c10 <- "<="
      criteria10 <- extract_numeric(criteria10)
    } else if (is.character(criteria10) == T){
      c10 <- "=="
    }



    ret <- sum(get(c1)(criteria_range1,criteria1) &
               get(c2)(criteria_range2,criteria2) &
               get(c3)(criteria_range3,criteria3) &
               get(c4)(criteria_range4,criteria4) &
               get(c5)(criteria_range5,criteria5) &
               get(c6)(criteria_range6,criteria6) &
               get(c7)(criteria_range7,criteria7) &
               get(c8)(criteria_range8,criteria8) &
               get(c9)(criteria_range9,criteria9) &
               get(c10)(criteria_range10,criteria10))

    options(warn=0)
    ret

  }
