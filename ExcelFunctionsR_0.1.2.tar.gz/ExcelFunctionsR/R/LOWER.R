# LOWER Function from Excel
#' Basic LOWER function from excel
#'
#' It acts similiarly to Excel's LOWER function.
#'
#' @param text Give the function a word to make it lower.Give the texts via vector if you want to perform it on multiple texts.
#' @import base
#' @export
#' @examples
#' LOWER("THIS IS SPARTAA! IS IT THOUGH AFTER LOWERING?")

LOWER <-
function(text){
  tolower(text)
}
