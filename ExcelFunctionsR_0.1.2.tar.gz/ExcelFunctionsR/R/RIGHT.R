# RIGHT Function from Excel
#' Basic RIGHT function from excel
#'
#' It acts similiarly to Excel's RIGHT function.
#'
#' @param text from where should it get the characters
#' @param num_chars how many characters should it get?
#' @import base
#' @export
#' @examples
#' RIGHT("Kayakata",4)

RIGHT <-
function(text,num_chars){
        substr(text,nchar(text) - num_chars + 1, nchar(text))

}



