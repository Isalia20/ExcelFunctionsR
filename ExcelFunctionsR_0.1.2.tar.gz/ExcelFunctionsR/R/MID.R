# MID Function from Excel
#' Basic MID function from excel
#'
#' It acts similiarly to Excel's MID function.
#'
#' @param text From whch text should it return the string?
#' @param start_num Where should it start counting from?
#' @param num_chars How many characters should it return?
#' @import base
#' @export
#' @examples
#' MID("Kayakata",5,4)

MID <-
function(text,start_num,num_chars){
      substr(text,start_num,start_num + num_chars-1)

}



