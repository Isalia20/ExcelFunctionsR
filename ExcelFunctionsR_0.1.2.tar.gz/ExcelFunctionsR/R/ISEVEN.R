# ISEVEN Function from Excel
#' Basic ISEVEN function from excel
#'
#' It acts similiarly to Excel's ISEVEN function.
#'
#' @param number Input the number for it to evaluate if it is even?
#' @import base
#' @export
#' @examples
#' ISEVEN(2)
#' ISEVEN(1)

ISEVEN <-
function(number){

        ifelse(number %% 2 != 0 , FALSE,TRUE)


}
