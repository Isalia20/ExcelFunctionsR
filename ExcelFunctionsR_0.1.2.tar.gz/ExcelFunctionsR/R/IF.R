# IF Function from Excel
#' Basic If function from excel
#'
#' It acts similiarly to Excel's If function. Works on vectors as well.
#'
#' @param logical_test  This is the usual test we run in excel which returns either TRUE or FALSE value. Use double equal signs for logical test if you want to equal.
#' @param valueifTrue   If the logical_test evaluates to TRUE then function will return the value you input here
#' @param valueifFalse  If the logical_test evaluates to FALSE then function will return the value you input here
#' @import base
#' @export
#' @examples
#' IF(iris$Species == "virginica","Yes","No")


IF <-
function(logical_test,valueifTrue = 0,valueifFalse = 0){
  ifelse(logical_test,valueifTrue,valueifFalse)
}
