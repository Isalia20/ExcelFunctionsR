# MINIF Function from Excel
#' Basic MINIF function from excel
#'
#' It acts similiarly to Excel's MINIF function.
#'
#' @param range Which range should it check the criteria against?
#' @param criteria What should be checked?
#' @param min_range From which range should it return the minimum from?
#' @import base
#' @import stringr
#' @export
#' @examples
#' MINIF(iris$Species,"virginica",iris$Sepal.Length)

MINIF <-
function(range,criteria, min_range) {

  options(warn=-1)

  if(is.na(as.numeric(criteria)) == F){
    c1 <- "=="
  } else if (str_detect(criteria,"^>") == T){
    c1 <- ">"
    criteria <- extract_numeric(criteria)
  }  else if (str_detect(criteria,"^<") == T){
    c1 <- "<"
    criteria <- extract_numeric(criteria)
  } else if (str_detect(criteria,"^>=")){
    c1 <- ">="
    criteria <- extract_numeric(criteria)
  } else if (str_detect(criteria,"^<=")){
    c1 <- "<="
    criteria <- extract_numeric(criteria)
  } else if (is.character(criteria) == T){
    c1 <- "=="
  }



  ret <- min(min_range[get(c1)(range,criteria)])
  options(warn=0)
  ret
}
