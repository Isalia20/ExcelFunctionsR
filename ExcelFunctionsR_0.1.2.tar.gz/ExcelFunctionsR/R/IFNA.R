# IFNA Function from Excel
#' Basic IFNA function from excel
#'
#' It acts similiarly to Excel's IFNA function.
#'
#' @param value Evaluate if it is NA.
#' @param value_if_na What should the function do if the value is NA.
#' @import base
#' @export
#' @examples
#' IFNA(NA,"It is NA")





IFNA <-
function(value,value_if_na){
  ifelse(is.na(value), value_if_na,value)
}
