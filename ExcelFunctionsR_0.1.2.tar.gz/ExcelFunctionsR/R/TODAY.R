# TODAY Function from Excel
#' Basic TODAY function from excel
#'
#' It acts similiarly to Excel's TODAY function.No need to give the arguments.
#'
#' @import base
#' @export
#' @examples
#' TODAY()

TODAY <-
function(){
  Sys.Date()
}
