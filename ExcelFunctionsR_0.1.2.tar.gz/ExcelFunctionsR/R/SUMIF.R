# SUMIF Function from Excel
#' Basic SUMIF function from excel
#'
#' It acts similiarly to Excel's SUMIF function.
#'
#' @param range Which range should it check the criteria against.
#' @param criteria what criteria should it check in range
#' @param sum_range Which range should it sum
#' @import base
#' @import stringr
#' @export
#' @examples
#' SUMIF(iris$Species,"virginica",iris$Sepal.Length)

SUMIF <-
function(range,criteria, sum_range) {

  options(warn=-1)

  if(is.na(as.numeric(criteria)) == F){
  c1 <- "=="
  } else if (str_detect(criteria,"^>") == T){
  c1 <- ">"
  criteria <- extract_numeric(criteria)
  }  else if (str_detect(criteria,"^<") == T){
    c1 <- "<"
    criteria <- extract_numeric(criteria)
  } else if (str_detect(criteria,"^>=")){
    c1 <- ">="
    criteria <- extract_numeric(criteria)
  } else if (str_detect(criteria,"^<=")){
    c1 <- "<="
    criteria <- extract_numeric(criteria)
  } else if (is.character(criteria) == T){
    c1 <- "=="
  }



  ret <- sum(sum_range[get(c1)(range,criteria)])
  options(warn=0)
  ret
}



