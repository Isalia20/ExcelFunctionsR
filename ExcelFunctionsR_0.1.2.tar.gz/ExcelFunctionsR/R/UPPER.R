# UPPER Function from Excel
#' Basic UPPER function from excel
#'
#' It acts similiarly to Excel's UPPER function.
#'
#' @param text Give this function the text to capitalize all the letters.Give this function words with a vector if you want to perform it on several texts.
#' @import base
#' @export
#' @examples
#' UPPER("is this sparta?")

UPPER <- function(text){
  toupper(text)
}



