# YEAR Function from Excel
#' Basic YEAR function from excel
#'
#' It acts similiarly to Excel's YEAR function.
#'
#' @param date Give the date argument so it can extract year from the date. Preferable to give the date via DATE function of this package.
#' @import base
#' @import lubridate
#' @export
#' @examples
#' YEAR(DATE(2020,1,1))

YEAR <-
  function(date){

    as.numeric(format(date, '%Y'))

  }


