# DATETOEXCELSERIES Function
#' Date to excel date series function
#'
#' @param date Convert R date type to Excel general date series, this might be helpful for Excel users.
#' @import base
#' @import lubridate
#' @import tidyr
#' @export
#' @examples
#' DATETOEXCELSERIES(DATE(2020,1,1))

DATETOEXCELSERIES <-
function(date){

ExcelOrigin <- DATE(1899,12,31)

extract_numeric(date - ExcelOrigin + 1)

}
