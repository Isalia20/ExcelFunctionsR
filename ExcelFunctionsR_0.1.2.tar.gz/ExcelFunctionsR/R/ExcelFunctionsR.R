#' ExcelFunctionsR: A package for using Excel functions in R.
#'
#' This package provides functions for users who are accustomed to Excel
#' functions and are stepping in the world of R.
#'
#' @author Irakli Salia \email{irakli.salia854@gmail.com}
#' @docType package
#' @name ExcelFunctionsR
