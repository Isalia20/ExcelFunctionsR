Return <- FIND("CRAN","OH CRAN")


expect_equal(Return,4L)
