Return <- ISLOGICAL(F)



expect_equal(Return,T)
