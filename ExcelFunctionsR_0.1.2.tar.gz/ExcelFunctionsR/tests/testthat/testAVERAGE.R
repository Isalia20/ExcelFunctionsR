Return <- AVERAGE(10,15,20)


expect_equal(Return,15L)



