Return <- MATCH("virginica",iris$Species)


expect_equal(Return,which(iris$Species == "virginica")[1])
