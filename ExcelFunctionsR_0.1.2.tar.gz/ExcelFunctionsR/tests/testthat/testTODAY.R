return <- TODAY()


expect_equal(return,Sys.Date())
