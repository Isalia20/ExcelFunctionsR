Return <- STDEV(1,2,3,4)



expect_equal(Return,1.29099444873581)
