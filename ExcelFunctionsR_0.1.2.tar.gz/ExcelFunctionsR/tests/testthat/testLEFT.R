Return <- LEFT("Fear what happens",4)


expect_equal(Return,"Fear")
