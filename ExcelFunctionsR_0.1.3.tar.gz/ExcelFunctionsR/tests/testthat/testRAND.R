set.seed(123)
Return <- RAND()


expect_equal(Return,0.287577520124614)
