Return <- COUNTIF(iris$Species,"virginica")


expect_equal(Return,50L)

