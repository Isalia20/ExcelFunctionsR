
expect_equal(NOW(),format(Sys.time(),"%Y-%m-%d %H:%M"))
