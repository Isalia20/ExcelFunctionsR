Return <- WEEKDAY(DATE(2020,1,1),"character")



expect_equal(Return,"Wednesday")
