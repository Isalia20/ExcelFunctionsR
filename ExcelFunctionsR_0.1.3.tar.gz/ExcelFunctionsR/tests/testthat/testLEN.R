Return <- LEN("SDQWDQWDQWD")



expect_equal(Return,11L)
