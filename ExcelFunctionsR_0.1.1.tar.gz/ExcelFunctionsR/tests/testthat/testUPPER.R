Return <- UPPER("is this lower?")


expect_equal(Return,"IS THIS LOWER?")
