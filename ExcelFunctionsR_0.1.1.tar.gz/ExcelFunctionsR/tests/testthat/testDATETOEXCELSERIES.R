Return <- DATETOEXCELSERIES(DATE(2020,1,1))


expect_equal(Return,43831)
