Return1 <- ISEVEN(2)
Return2 <- ISEVEN(1)



expect_equal(Return1,T)
expect_equal(Return2,F)
