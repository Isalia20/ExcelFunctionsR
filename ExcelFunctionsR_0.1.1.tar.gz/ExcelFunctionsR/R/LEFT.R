# LEFT Function from Excel
#' Basic LEFT function from excel
#'
#' It acts similiarly to Excel's LEFT function.
#'
#' @param text the text you want to select characters from left.
#' @param num_chars How many characters should it select?
#' @import base
#' @export
#' @examples
#' LEFT("Fear what happens on earth stays on earth",4)


LEFT <-
function(text,num_chars){
      substr(text,1,num_chars)

}
