# NOW Function from Excel
#' Basic NOW function from excel
#'
#' It acts similiarly to Excel's NOW function.
#'
#' @import base
#' @export
#' @examples
#' NOW()

NOW <-
function(){
  format(Sys.time(),"%Y-%m-%d %H:%M")
}

