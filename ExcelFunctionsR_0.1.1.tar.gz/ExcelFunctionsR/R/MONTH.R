# MONTH Function from Excel
#' Basic MONTH function from excel
#'
#' It acts similiarly to Excel's MONTH function.
#'
#' @param date  Enter the date to get the month from.
#' @import base
#' @export
#' @examples
#' MONTH(DATE(2020,12,1))

MONTH <-
function(date){
  as.numeric(format(date, '%m'))
}



