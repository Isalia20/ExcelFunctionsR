# INDEX Function from Excel
#' Basic INDEX function from excel
#'
#' It acts similiarly to Excel's INDEX function.
#'
#' @param array Which array/table should it use?
#' @param row_num Which row should it return the value from?
#' @param column_num Which column should it return the value from?
#' @import base
#' @export
#' @examples
#' INDEX(iris,3,2)

INDEX <-
function(array,row_num,column_num = 1){

  if (is.vector(array)){

    array[row_num, drop = T ]

  } else if (is.data.frame(array) || is.matrix(array)){

    array[row_num,column_num, drop = T]


  }
}






