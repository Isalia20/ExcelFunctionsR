# MATCH Function from Excel
#' Basic MATCH function from excel
#'
#' It acts similiarly to Excel's MATCH function.
#'
#' @param lookup_value what value to lookup
#' @param lookup_array Where should it lookup the value
#' @import base
#' @export
#' @examples
#' MATCH("virginica",iris$Species)

MATCH <-
function(lookup_value,lookup_array){

  which(lookup_array == lookup_value)[1]

}
