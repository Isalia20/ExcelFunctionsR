# RAND Function from Excel
#' Basic RAND function from excel.
#'
#' It acts similiarly to Excel's RAND function.No need to specify the arguments/parameters.
#'
#' @import base
#' @export
#' @examples
#' RAND()

RAND <-
function(){
  runif(1,min = 0, max =1)
}
