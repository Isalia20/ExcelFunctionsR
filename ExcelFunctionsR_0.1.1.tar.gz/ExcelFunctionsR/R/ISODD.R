# ISODD Function from Excel
#' Basic ISODD function from excel
#'
#' It acts similiarly to Excel's ISODD function.
#'
#' @param number Input the number for it to evaluate if it is an odd number? Works on vectors/arrays as well.
#' @import base
#' @export
#' @examples
#' ISODD(1)
#' ISODD(2)

ISODD <-
function(number){

  ifelse(number %% 2 !=0, TRUE, FALSE)
}
