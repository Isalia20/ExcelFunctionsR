# OR Function from Excel
#' Basic OR function from excel
#'
#' It acts similiarly to Excel's OR function.
#'
#' @param logical1,logical2,logical3,logical4,logical5,logical6,logical7,logical8,logical9,logical10,logical11,logical12,logical13,logical14,logical15,logical16,logical17,logical18,logical19,logical20,logical21,logical22,logical23,logical24,logical25,logical26,logical27,logical28,logical29,logical30,logical31,logical32 Give the function a logical argument. The one that returns either TRUE or FALSE.
#' @import base
#' @export
#' @examples
#' OR(iris$Species == "virginica",iris$Sepal.Length > 6)


OR <-
function(logical1,logical2= F ,logical3= F,logical4= F,logical5= F,logical6= F,logical7= F,logical8= F,logical9= F,logical10= F,logical11= F,logical12= F,logical13= F,logical14= F,logical15= F,logical16= F,logical17= F,logical18= F,logical19= F,logical20= F,logical21= F,logical22= F,logical23= F,logical24= F,logical25= F,logical26= F,logical27= F,logical28= F,logical29= F,logical30= F,logical31= F,logical32= F){

  logical1 | logical2 | logical3 | logical5 | logical6 | logical7 | logical8 | logical9 | logical10 | logical11 | logical12 | logical13 | logical14 | logical15 | logical16 | logical17 | logical18 | logical19 | logical20 | logical21 | logical22 | logical23 | logical24 | logical25 | logical26 | logical27 | logical28 | logical29 | logical30 | logical31 | logical32

}
