# ISNUMBER Function from Excel
#' Basic ISNUMBER function from excel
#'
#' It acts similiarly to Excel's ISNUMBER function.
#'
#' @param value Input the number for it to evaluate if it is number? Works on vectors/arrays as well.
#' @import base
#' @export
#' @examples
#' ISNUMBER(2)
#' ISNUMBER("2")


ISNUMBER <-
function(value){
  is.numeric(value)
}
