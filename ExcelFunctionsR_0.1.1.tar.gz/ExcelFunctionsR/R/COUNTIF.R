# COUNTIF Function from Excel
#' Basic COUNTIF function from excel
#'
#' It acts similiarly to Excel's COUNTIF function.
#'
#' @param range Specify range for Countif
#' @param criteria Give the criteria to check the range for.
#' @import base
#' @import stringr
#' @export
#' @examples
#' COUNTIF(iris$Species,"setosa")


COUNTIF <-
function(range,criteria){

  options(warn=-1)

  if(is.na(as.numeric(criteria)) == F){
    c1 <- "=="
  } else if (str_detect(criteria,"^>") == T){
    c1 <- ">"
    criteria <- extract_numeric(criteria)
  }  else if (str_detect(criteria,"^<") == T){
    c1 <- "<"
    criteria <- extract_numeric(criteria)
  } else if (str_detect(criteria,"^>=")){
    c1 <- ">="
    criteria <- extract_numeric(criteria)
  } else if (str_detect(criteria,"^<=")){
    c1 <- "<="
    criteria <- extract_numeric(criteria)
  } else if (is.character(criteria) == T){
    c1 <- "=="
  }

  ret <- sum(get(c1)(range,criteria))

  options(warn=0)
  ret

}
