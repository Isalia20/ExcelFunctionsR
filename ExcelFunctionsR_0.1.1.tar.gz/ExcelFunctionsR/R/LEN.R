# LEN Function from Excel
#' Basic LEN function from excel
#'
#' It acts similiarly to Excel's LEN function.
#'
#' @param text amount of characters in the word.
#' @import base
#' @export
#' @examples
#' LEN("This is great!")

LEN <-
function(text){
        nchar(text)
}

