# REPT Function from Excel
#' Basic REPT function from excel
#'
#' It acts similiarly to Excel's REPT function.
#'
#' @param text Which text should it repeat n time?
#' @param number_times How many times should the function repeat the given text.
#' @param AsOne Should function concatenate the text or should it return seperately as a vector(Vector is same as array in Excel)
#' @import base
#' @export
#' @examples
#' REPT("Oi",2,AsOne = TRUE)
#' REPT("Oi",2,AsOne = FALSE)

REPT <-
function(text,number_times,AsOne = T){
        if (AsOne == F){rep(text,number_times)
        } else{


          if (is.numeric(text) == T) { as.numeric(paste(rep(text,number_times),collapse = ""))
          } else {

            paste(rep(text,number_times),collapse = "")

          }
}
}





