# RANDBETWEEN Function from Excel
#' Basic RANDBETWEEN function from excel
#'
#' It acts similiarly to Excel's RANDBETWEEN function.
#'
#' @param bottom Give the function a bottom floor for the randbetween
#' @param top Give the function a top ceiling for the randbetween
#' @param number How many numbers should it generate?
#' @import base
#' @export
#' @examples
#' RANDBETWEEN(1,100, number = 1)
#' RANDBETWEEN(1,100, number = 3)

RANDBETWEEN <-
function(bottom,top, number = 1) {
  floor(runif(number,min = bottom, max = top+1))
}
